function [inflation_rate] = calculate_inflation(inflation_table,cost_year)
%Function reads in inflation rate table and calculates rate of inflation or
%deflation in relation to the base year
%   Detailed explanation goes here
    
    base_year = 2012; % This corresponds to the base year of the MRIO - user can change this accordingly
    
    if cost_year>base_year % If the cost year is after the base year then the function needs to calculate a compound deflation rate
          
        timeseries = inflation_table(1,:);
        annual_inflation = inflation_table(3,:);
        index_base_year = find(timeseries==base_year);
        index_cost_year = find(timeseries==cost_year);
        index_timeseries = 1:length(timeseries);
        deflation_factor_years = index_timeseries(index_timeseries>index_base_year & index_timeseries<index_cost_year);
        deflation_rate = prod(annual_inflation(deflation_factor_years))*annual_inflation(index_cost_year);
        inflation_rate = 1/deflation_rate;
        
    elseif cost_year<2012 % If the cost year is prior to the base year then the function needs to calculate a compound inflation rate
        
        timeseries = inflation_table(1,:);
        annual_inflation = inflation_table(3,:);
        index_base_year = find(timeseries==base_year);
        index_cost_year = find(timeseries==cost_year);
        index_timeseries = 1:length(timeseries);
        inflation_factor_years = index_timeseries(index_timeseries>index_cost_year & index_timeseries<index_base_year);
        inflation_rate = prod(annual_inflation(inflation_factor_years))*annual_inflation(index_cost_year);
        
    else
        inflation_rate = 1;
        
    end

end

