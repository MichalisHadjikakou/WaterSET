%function [Overall_avg] = Conventional_plants_weighted_average(~,capacity1,capacity2,capacity3)
%% CALCULATING WEIGHTED AVERAGE OF CONVENTIONAL WATER TREATMENT PLANTS

% Author: Michalis Hadjikakou, UNSW
% Last updated: 20/04/2016
% Data source: McGivney & Kawamura (2008) - supplementary excel files based
% on Appendix containing 10 and 100 MGD plant input recipes
%   
    
    capacity1 = 10;
    capacity2 = 100;
    capacity3 = 300;
    WSOs = cellstr(['231a';'231b';'231c';'241a';'241b';'241c';'242a';'242b';'242c']); 
    Overall_avg = zeros(length(WSOs),8); % Number of WSOs and 

    for i=1:length(WSOs)

        if strcmp(WSOs(i),'242c')==0    
    
            sheet = 'TABLE'; 
            Range = 'J5:R47';
            filename1 = strjoin([num2str(capacity1),'-MGD_WTP_',WSOs(i),'.XLS'],'');
            filename2 = strjoin([num2str(capacity2),'-MGD_WTP_',WSOs(i),'.XLS'],'');

            Plant_min = xlsread(filename1,sheet,Range); % Reading appropriate excel sheet cells 
            Plant_max = xlsread(filename2,sheet,Range); % Reading appropriate excel sheet cells 
            Plant_min(isnan(Plant_min))=0;    
            Plant_max(isnan(Plant_max))=0;
            
            Shares_min = Plant_min(:,1)/sum(Plant_min(:,1));
            Avg_min = Shares_min'*Plant_min(:,2:end); % Matrix multiplication to estimate sums of each weighted multiplied column

            Shares_max = Plant_max(:,1)/sum(Plant_max(:,1));
            Avg_max = Shares_max'*Plant_max(:,2:end); % Matrix multiplication to estimate sums of each weighted multiplied column

            Overall_avg(i,:) = (Avg_min+Avg_max)/2; % Overall average for both plants
        
        else
            
            sheet = 'TABLE'; 
            Range = 'J5:R47';
            filename1 = strjoin([num2str(capacity1),'-MGD_WTP_',WSOs(i),'.XLS'],'');
            filename2 = strjoin([num2str(capacity2),'-MGD_WTP_',WSOs(i),'.XLS'],'');
            filename3 = strjoin([num2str(capacity3),'-MGD_WTP_',WSOs(i),'-2.XLS'],'');
            
            Plant_min = xlsread(filename1,sheet,Range); % Reading appropriate excel sheet cells
            Plant_med = xlsread(filename3,sheet,Range);
            Plant_max = xlsread(filename3,sheet,Range); % Reading appropriate excel sheet cells 
            Plant_min(isnan(Plant_min))=0;
            Plant_med(isnan(Plant_med))=0;
            Plant_max(isnan(Plant_max))=0;

            Shares_min = Plant_min(:,1)/sum(Plant_min(:,1));
            Avg_min = Shares_min'*Plant_min(:,2:end); % Matrix multiplication to estimate sums of each weighted multiplied column
            
            Shares_med = Plant_med(:,1)/sum(Plant_med(:,1));
            Avg_med = Shares_med'*Plant_med(:,2:end); % Matrix multiplication to estimate sums of each weighted multiplied column

            Shares_max = Plant_max(:,1)/sum(Plant_max(:,1));
            Avg_max = Shares_max'*Plant_max(:,2:end); % Matrix multiplication to estimate sums of each weighted multiplied column

            Overall_avg(i,:) = (Avg_min+Avg_med+Avg_max)/3; % Overall average for both plants
            
        end
            
    end

%end