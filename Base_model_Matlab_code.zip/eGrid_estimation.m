function [Energy_CO2e] = eGrid_estimation(postcode)
%% CO2e estimation of energy-related GHG emissions
%  Author: Michalis Hadjikakou, UNSW
%  Last updated: 14/04/2016
%  Inputs: EGrid calculation sheets (source:
%  https://www.epa.gov/energy/egrid), US postcode used to identify grid
%  subregion and calculate associated carbon emissions 

    %% 1. Reading in eGrid power profiler tool sheets (source: https://www.epa.gov/energy/power-profiler, last updated 08 October 2015)

    Emission_factors = readtable('power_profiler_zipcode_tool_2012_v6-0.xlsx','Sheet','Emission Factors','Range','A04:E30');
    Subregion = readtable('power_profiler_zipcode_tool_2012_v6-0.xlsx','Sheet','Zip-Subregion');

    %% 2. Finding primary/secondary/tertiary subregion(s) based on postcode
    
    postcode_num = str2num(postcode); % Converting text to number to allow indexing
    index_row = Subregion.ZIP_numeric_==postcode_num;
    grids = Subregion(index_row,4:6); % Indexing 
    grids_array = table2array(grids);
    grids_array(strcmp('',grids_array)) = []; % Eliminating missing networks
    
    %% 3. Calculating 100-year GHG CO2e emissions based on emission factors for each subregion
    
    Total_GHG = zeros(length(grids_array),1); % Column vector where results will be saved
    
    for i = 1:length(grids_array) % Looping through grids array elements
    
    Emission_rates = Emission_factors(strcmp(Emission_factors.SUBRGN,grids_array(i)),3:5);
    GHG_factors = table2array(Emission_rates);
    Total_GHG(i) = 0.000453592*(GHG_factors(1)+(25*GHG_factors(2))+(298*GHG_factors(3))); % Standard GWP calculation to sum up CH4,N2O and CO2 into CO2-e
    
    end
    
    Energy_CO2e = mean(Total_GHG); % Emissions are simply taken as the average of any number of primnary/secondary/tertiary grids
    % PLEASE NOTE THAT FINAL NUMBER IS IN CO2-e (t/MWh)!!!
    
end

