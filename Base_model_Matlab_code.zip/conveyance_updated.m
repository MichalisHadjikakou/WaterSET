function [Total_pump_electricity,Total_pump_OPEX_breakdown,Total_pump_CAPEX_breakdown,Pipe_PVC,Pipe_Iron] = conveyance_updated(head,costs,pumping,material,piping)
%%  CONVEYANCE COST AND ENERGY CALCULATION FUNCTION

%   Sub-function of main TBL function dealing with head and power
%   calculations depending on user inputs
%   Author: Michalis Hadjikakou, UNSW Australia
%   Last updated: 20/02/2017
%   
%%
% *Function inputs (components of 'head' vector from main function)*
%%
% 
% * head(1): head loss (sum of all major and minor losses)
% * head(2): pump efficiency (default value = 0.6)
% * pumping: 5 x 2 matrix with capacity and number for each station size
% * costs(2): plant service life (used to determine annualised CAPEX)
% * material : 6-element vector containing material type (choice between
% * 'PVC' and 'Ductile Iron' in current model setup
% * piping: 6 x 3 matrix with length, diameter and price (per inch diameter
% per linear foot)

%%  1. Reading in and setting parameters

 %  1.1 Cost breakdowns for CAPEX and OPEX
    CAPEX_breakdown_low =[0,40,0,0,19,36,5,0]; % Applicable to lower head values (source: Sharma et al. (2013) - corresponds to unit process #34 in cost curves spreadsheet)
    CAPEX_breakdown_high =[0,45,0,0,15,27,13,0]; % Applicable to higher head values (source: Sharma et al. (2013) - corresponds to unit process #35 in cost curves spreadsheet)
    OPEX_breakdown_low = [72,0,0,22,6]; % Applicable to lower head values (source: Sharma et al. (2013) - corresponds to unit process #34 in cost curves spreadsheet)
    OPEX_breakdown_high = [81,0,0,15,4]; % Applicable to higher head values (source: Sharma et al. (2013) - corresponds to unit process #35 in cost curves spreadsheet)

    ENR_CCI_IO = 9308; % Average 2012 ENR CCI - corresponds to year of IO table
    ENR_Sharma = 9027; % April 2011 ENR for OPEX cost curve
%%  2. Performing calculations

 %  2.1 Head/energy calculations - IMPERIAL to METRIC conversions
    gamma = 1000; % ? - density of fluid (kg/m3)
    g = 9.81; % g - gravity (m/s2)
    ft_to_m = 0.3048;  % feet to metres
    MGD_to_m3h = 157.72549166660207; % MGD (US) to m3/h
    MGD_to_GPM = 694.444444444444; % converting MGD to gallons per minute
    
    % Formula: q ? g h / (3.6 106)   , source: http://www.engineeringtoolbox.com/pumps-power-d_505.html
    % Perfoming unit conversions from imperial to metric 
    
    % Creating indices to select only non-zero pumping stations entered by
    % the user - this also takes care of empty value cells
    ind_pump = pumping(:,2)>0; % selecting only positive pump cells
    number = pumping(:,2); % second column is number of pumps
    numb_selected = number(ind_pump); % selecting non-zero numbers
    pump_capacity = pumping(:,1); % selecting first column (capacity)
    selected_pumps = pump_capacity(ind_pump); % selected only pump capacities with positive number of stations
    ind_selected = selected_pumps>0; % selecting only non-zero pump capacities
    pump_size = selected_pumps(ind_selected); % SELECTED SIZES (CAPACITIES)
    pump_number = numb_selected(ind_selected); % SELECTED NUMBERS
    
    % Creating variables to save loop results
    Pump_electricity_per_year = zeros(1,length(pump_size));% empty vector for pump electricity estimate
    Conveyance_CAPEX_breakdown = zeros(length(pump_size),length(CAPEX_breakdown_low));% empty vector for CAPEX breakdown for each pumping station
    Conveyance_OPEX_breakdown = zeros(length(pump_size),length(OPEX_breakdown_low));% empty vector for OPEX breakdown for each pumping station
    
    % Looping through pumping stations of different capacities 
    
    for i= 1:length(pump_size) % length of loop depends on the number of different capacities specified by the user 
        
        capacity = pump_size(i); % calculation performed for each pump size
        q = capacity* MGD_to_m3h; % flow capacity(m3/h)
        rho = 1000; % density of fluid (kg/m3) - ?
        h = head(1)*ft_to_m; %differential head including head losses (m)

        Hydraulic_power = q*rho*g*h/(3.6*10^6); % theoretical pump power (kW)
        Shaft_power = Hydraulic_power/head(2); % this is simply hydraulic power divided by pump efficiency to give the total power required (kW)

      % 2.2 Electricity and cost calculations
        Pump_electricity_per_year(i) = (Shaft_power*24*365)*pump_number(i); % Converting from hourly to yearly to ensure compatibility with other values - this should be in kWh and multiplied by the number of pumping stations
        Electricity_cost = Pump_electricity_per_year(i)*0.1006; % Using electricity price for 2012
        OPEX_conveyance_low = Electricity_cost*OPEX_breakdown_low/OPEX_breakdown_low(1); % Breakdown vector for low 
        OPEX_conveyance_high = Electricity_cost*OPEX_breakdown_high/OPEX_breakdown_high(1); % Breakdown vector for high

        if (head(1)) >= 300 % If head is more than 300ft a booster is needed - according to calculations by Hazen & Sawyer (see spreadhsheet '14-03 TBL Pumping and Conveyance Module Development')
            
        % Cost curve estimates (source: Pumping Station Design, 3nd. Ed., G.M. Jones Chief Ed. , Butterworth-Heinemann, MA, 2006)
            CAPEX_cost_high = (ENR_CCI_IO/4500*658000*capacity^0.716)*pump_number(i); 
            CAPEX_cost_low = (ENR_CCI_IO/4500*260000*capacity^0.713)*pump_number(i);
            CAPEX_cost_average = mean([CAPEX_cost_high,CAPEX_cost_low])*pump_number(i);
        % Also adding booster since head is more than 300ft    
            Booster_cost_high = (ENR_CCI_IO/4500*255000*capacity^0.746)*pump_number(i);
            Booster_cost_low = (ENR_CCI_IO/4500*96200*capacity^0.758)*pump_number(i);
            Booster_cost_average = (mean([Booster_cost_high,Booster_cost_low]))*pump_number(i);
        % Total cost is equal to pumping station plus booster    
            Annual_conveyance_CAPEX = (CAPEX_cost_average + Booster_cost_average)/costs(2);
            Conveyance_CAPEX_breakdown(i,:) = Annual_conveyance_CAPEX*(CAPEX_breakdown_high/100); %T
            Conveyance_OPEX_breakdown(i,:) = OPEX_conveyance_high*ENR_CCI_IO/ENR_Sharma;

        else 

        % Cost curve estimates (source: Pumping Station Design, 3nd. Ed., G.M. Jones Chief Ed. , Butterworth-Heinemann, MA, 2006)    
            CAPEX_cost_high = ENR_CCI_IO/4500*658000*capacity^0.716;
            CAPEX_cost_low = ENR_CCI_IO/4500*260000*capacity^0.713;
            CAPEX_cost_average = mean([CAPEX_cost_high,CAPEX_cost_low]);

            Annual_conveyance_CAPEX = CAPEX_cost_average/costs(2);
            Conveyance_CAPEX_breakdown(i,:) = Annual_conveyance_CAPEX*(CAPEX_breakdown_low/100);
            Conveyance_OPEX_breakdown(i,:) = OPEX_conveyance_low*ENR_CCI_IO/ENR_Sharma; 

        end
        
    end
    
%%  3. Pipe type, length and diameter - calculation of costs related to pipe requirements
    
    % Creating index of rows with valid values
    non_zeros = piping>0; % index of all non-zero values 
    sum_non_zeros = sum(non_zeros,2); % rowsum of non-zero index
    ind_piping = sum_non_zeros>2;% selecting only rows with sum greater than 2 (3 or over)
    
    % Applying index to piping and material variables 
    pipe_costs = piping(ind_piping,:);
    material_types = material(ind_piping);
    
    % Calculating costs and seperating into different materials 
    Total_costs = prod(pipe_costs,2); % row-wise product
    Pipe_PVC = sum(Total_costs(strcmp(material_types,'PVC')))/costs(2); % Annualised PVC pipe costs
    Pipe_Iron = sum(Total_costs(strcmp(material_types,'Ductile Iron')))/costs(2); % Annualised Ductile Iron pipe costs
    
%%  4. Calculating final function outputs - 

    Total_pump_electricity = sum(Pump_electricity_per_year); % Total electricity requirements in kWh
    Total_pump_OPEX_breakdown = sum(Conveyance_OPEX_breakdown,1); % Breakdown of total OPEX - in 5 standard OPEX categories including electricity (removed for CO2 emission purposes later) and labour (added to Value Added at a later stage) 
    Total_pump_CAPEX_breakdown = sum(Conveyance_CAPEX_breakdown,1); % Breakdown of total CAPEX - in 8 standard CAPEX categories
    
end

