function [cost_breakdown,value_added,wages] = Calculate_CAPEX_updated(x,quantity)
%% FUNCTION READING IN COST CURVE EQUATIONS AND ESTIMATING CAPEX AND OPEX
% Author: Michalis Hadjikakou, UNSW
% Last updated: 28/02/2017
% Inputs: x (user input vector - refers to size of each unit process - units vary) & 'Cost_curves.csv' spreadsheet containing: a(x^3-coefficient), b(x^2-coefficient), c(ln coefficient), d(x-coeficient), e (x-power),f(y-intercept) 
% Sources: Sharma et al. (2013), McGivney & Kawamura (2008), Plumley et al. (2014)....
% For cost indices see 'Cost Indices' tab in WERF-14-03 Tool Spreadsheet

%% 1. Reading in necessary files from directory and setting parameters

    Costs = readtable('Cost_curves_CAPEX_updated.xlsx'); % Spreadsheet containing cost curve relationships for different unit processes
    Cost_curve_indices = readtable('CAPEX_cost_indices_updated.xlsx'); % Spreadsheet containing full range of cost curve indices to allow scaling up/down - better than using single ENR CCI Index
    ENR_CCI_indices = xlsread('ENR_CCI_timeseries.xlsx','ENR_CCI_timeseries','B2:N28'); % Reading in complete ENR CCI index table - currently ends May 2016
    ENR_CCI_years = xlsread('ENR_CCI_timeseries.xlsx','ENR_CCI_timeseries','A2:A28'); % Reading in years vector (1990-2016)
    [~,ENR_CCI_months] = xlsread('ENR_CCI_timeseries.xlsx','ENR_CCI_timeseries','B1:N1'); % Reading in months vector including Average (length=13)
    
%% 2. Finding correct year/month indices and ensuring all units are compatible    
    
    IO_table_year = 2012;
    Cost_year = Costs.Year; % Vector of year for which cost curves are applicable - allows scaling to 2012 average on the basis of ENR CCI (see 'ENR_CCI_timeseries.xlsx')  
    Cost_month = Costs.Month; % Vector of month for which costs are available - used to look within ENR CCI table to find appropriate cell
    ENR_index_IO = ENR_CCI_indices(ENR_CCI_years==IO_table_year,strcmp(ENR_CCI_months,'Average')); % Selecting the average ENR CCI for the IO_table_year - can modify accordingly
    
    Cost_scaling_factors = ones(length(Cost_year),1); % Empty vector where scaling factors are to be saved
%     
%     for i = 1:length(Cost_year)
%         
%         index_year = ENR_CCI_years==Cost_year(i);
%         index_month = strcmp(ENR_CCI_months,Cost_month(i));
%     
%         if strcmp(Costs.Cost_curve_source(i),'McGivney & Kawamura (2008)') % The McGivney & Kawamura (2008) cost curves are for Los Angeles so this requires additional correction
% 
%             Cost_scaling_factors(i) = ENR_index_IO/ENR_CCI_indices(index_year,index_month)*(8889/6533); % By converting ENR CCI to 2007 Los Angeles and then 2012 national prices - see McGivney & Kawamura (2008) and http://www.enr.com/economics
%         % Alternatively can use other indices such as BLS PPI or
%         % Handy-Whitman Index - see supplementary Excel files in McGivney &
%         % Kawamura (2008)
%         % https://www.wrallp.com/about-us/handy-whitman-index - can also be used
%         % for sensitivity analysis to consider how varying costs affect final values  
%     
%         else
%             Cost_scaling_factors(i) = ENR_index_IO/ENR_CCI_indices(index_year,index_month); % Other cost curves are national therefore no additional adjustment required
%     
%         end    
%     
%     end
    
    Cost_scaling_factors(strcmp(Costs.Unit,'$M'))= Cost_scaling_factors(strcmp(Costs.Unit,'$M'))*1000000; % Correcting units - some cost curves are in millions of dollars
    
%% 2. CAPEX calculations

    % 2.1 Estimate total CAPEX based on individual cost curve equation for each unit process 
    
    x(isnan(x))=0; % Ensuring that any NaN values are set to zero
    
    a = Costs.Cubic_coef; % Cubic coefficient - zero if none
    b = Costs.Quadratic_coef; % Quadratic coefficient - zero if none
    c = Costs.Logarithm; % Loagarithmic coefficient - zero if none
    d = Costs.Coeficient; % Power function - zero if none
    e = Costs.Power; % x-coefficient - 1 if none
    f = Costs.Intercept; % y-intercept - zero if none

    y = zeros(size(Costs,1),1); % Column vector for saving individual unit process cost estimates
    
    for j = 1:length(Cost_year)
    
        %y(i) = a(i)*x(i)^3 + b(i)*x(i)^2 + c(i)*log(x(i))+ d(i)*x(i)^e(i) + f(i); % Generalised formula for any quadratic, power or linear cost curve- can be modified to include polynomials of higher order
        y(j) = nansum([a(j)*x(j)^3,b(j)*x(j)^2,c(j)*log(x(j)),d(j)*x(j)^e(j),f(j)]); % Ensuring that any NaN values emerging from log(0) values do not throw off the result

    end
    
    Total_costs = y.*Cost_scaling_factors.*quantity; % Each vector element multiplied by respective scaling factor and the number of each unit process
    
    % 2.2 Calculating CAPEX beakdown into individual components
    %(Sitework, Equipment, Concrete, Steel, Labour, Pipes, Electronics,
    %Housing)
    
    CC_matrix = zeros(length(Total_costs),8); % number of rows equal to unit processes and then 8 columns, one for each cost breakdown category 
    
    for i = 1:8 % looping across eight CAPEX breakdown categories 
        
%         for k = 1:length(Total_costs) % Looping across each unit process (n=69) 

     % Vectorisation of code to avoid second loop and improve performance       
            CC_matrix(:,i) = (Total_costs.* Costs.(13+i))/100.*(Cost_curve_indices.(12+i)./Cost_curve_indices.(4+i)); % Selecting the right current and past indices for each unit process (see 'CAPEX_cost_indices.xlsx)
            
%             CC_matrix(k,1) = Total_costs(k).* Costs.Sitework(k)/100; % Sitework vector percentage
%             CC_matrix(k,2) = Total_costs(k).* Costs.Equipment(k)/100; % Equipment vector percentage
%             CC_matrix(k,3) = Total_costs(k).* Costs.Concrete(k)/100; % Concrete vector percentage
%             CC_matrix(k,4) = Total_costs(k).* Costs.Steel(k)/100; % Steel vector percentage
%             CC_matrix(k,5) = Total_costs(k).* Costs.Labour(k)/100; % Labour vector percentage
%             CC_matrix(k,6) = Total_costs(k).* Costs.Pipe_valves(k)/100; % Pipes vector percentage
%             CC_matrix(k,7) = Total_costs(k).* Costs.Instrumentation(k)/100; % Electronic vector percentage
%             CC_matrix(k,8) = Total_costs(k).* Costs.Housing(k)/100; % Electronic vector percentage

%         end
        
    end
    % 2.3 Calculating CAPEX add-ons to estimate total construction cost -
    % as per McGivney & Kawamura (2008) and Plumlee et al. (2014)
    
    Updated_total = sum(sum(CC_matrix)); % This is the total sum of all matrix elements which corresponds to the total update CAPEX cost 
    
    Yard_piping = sum(Updated_total)*0.1;
    Landscaping = sum(Updated_total)*0.05;
    Site_electrical = sum(Updated_total)*0.2;
    
    Subtotal_construction = sum(Updated_total)+Yard_piping+Landscaping+Site_electrical;
    
    Contractor_OHP = Subtotal_construction*0.15;
    Contingency = Subtotal_construction*0.3; 
    
    Total_construction = Subtotal_construction+Contractor_OHP+Contingency;
    
    Engineering_legal = Total_construction*0.35;
    
    Total_project_cost = Total_construction+Engineering_legal;
    
%% 3. Saving CAPEX cost breakdown 

    % 3.1 Each sub-cost is saved in the appropriate vector element      
    
    CC_vector = sum(CC_matrix); % Total capital cost vector where each element corresponds to the total of each CAPEX category
     
    value_added = CC_vector(5)+ Contractor_OHP; % Labour and overhead+profit
    wages = CC_vector(5); % Labour only - related to construction
    
    cost_breakdown = CC_vector;
    cost_breakdown(5) = [];
    cost_breakdown(8) = Yard_piping;
    cost_breakdown(9) = Landscaping;
    cost_breakdown(10) = Site_electrical;
    cost_breakdown(11) = Engineering_legal;
end

