function [Inputs_column] = locate_sectors_US(sector_concordance,New_sector_labels,cost_breakdown,T)
%%  
%   Detailed explanation goes here
    CAPEX_conc = sector_concordance; % Converting table to cell to allow easy manipulation
    
    num_CAPEX_conc = zeros(size(CAPEX_conc,1),size(CAPEX_conc,2)); % Empty matrix where sector numbers are to be saved
    ind_sector = ~strcmp(CAPEX_conc,'-'); % Indicates position of meaningful sector names - 'z' denotes a non-sector or empty cell 

    for i = 1:size(CAPEX_conc,1); % Finding out CAPEX industry sector numbers
        try              % Attempt to perform some computation
        sectors = strtrim(CAPEX_conc(i,ind_sector(i,:)));
        for j = 1:length(sectors);
            IO_sector = find(strcmp(sectors(j),strtrim(New_sector_labels)));
            ind_pos = find(ind_sector(i,:)>0);
            num_CAPEX_conc(i,ind_pos(j))= IO_sector(2);    
        end 
        catch exception  % Catch the exception - this is done to address problem that labour does not concord directly to an IO sector
        continue       % Pass control to the next loop iteration
        end
    end
    
    CAPEX_US_sectors = num_CAPEX_conc(:,4:6); % Selecting only US part of the concordance matrix - SEE BELOW FOR AUSTRALIA!!!!!
    % AUS_sectors = num_CAPEX_conc(:,1:3);
    
    % 2.5 Creating customised CAPEX annual input vector 
    US_CAPEX = CAPEX_US_sectors; %([1:4,6:end],:); % Labour is excluded from original file otherwise would need to subset CAPEX to exclude it - not necessary here
    [row_US,col_US]= find(US_CAPEX); % Finding non-zero values and creating row and column indices
    matrix_US = sortrows([row_US col_US US_CAPEX(US_CAPEX>0) US_CAPEX(US_CAPEX>0)],1); % Creating matrix using row and column indices and industry sectors numbers concordance (x2)
    matrix_US(:,5)= 0; %Adding one more column where input value will be saved in loop
    
    for exp_category = 1:length(cost_breakdown); % Performing operation for all expenditure categories (running loop across numbers on first column)
        ind_exp = find(matrix_US(:,1)== exp_category); % Row index to select appropriate sector numbers
        matrix_US(ind_exp,5) = cost_breakdown(exp_category)/length(ind_exp);%./PP_to_BP_ISAPC(matrix_AUS(ind_exp,3)); % Distributing the expenditure equally across relevant IO sectors and converting to basic prices using appropriate factor    
    end 
    
    inputs_col = zeros(length(T),size(matrix_US,1)); % Empty vector where results will be saved - one column at a time to avoid value replacement and subsequent data loss
    
    for input = 1:size(matrix_US,1); % Loop along rows of matrix to pick out inputs
        inputs_col(matrix_US(input,4),input)= matrix_US(input,5);
    end
    
    Inputs_column = sum(inputs_col,2)/1000; % sum of all inputs for WSO converted to k$ (monetary unit used by Eora)

end

