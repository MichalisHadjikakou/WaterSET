%% CALCULATING WEIGHTED AVERAGE FOR O&M OF CONVENTIONAL WATER TREATMENT PLANTS

% Author: Michalis Hadjikakou, UNSW
% Last updated: 19/06/2016
% Data source: McGivney & Kawamura (2008) and Sharma et al. (2013)- supplementary excel files based
% on Appendix containing 10 and 100 MGD plant input recipes
    
% 1. Setting and reading in fixed parameters not affected by loop

    capacity1 = 10;
    capacity2 = 100;
    capacity3 = 300;
    WSOs = cellstr(['231a';'231b';'231c';'241a';'241b';'241c';'242a';'242b';'242c']); 
    Overall_avg = zeros(length(WSOs),5); % Number of WSOs across 5 expenditure categories - for saving results
    [~,Unit_processes] = xlsread('Default_unit_processes_O_and_M.xlsx','Sheet1','B2:B53'); % Full list of unit processes offered in the tool
    Exp_shares = xlsread('Default_unit_processes_O_and_M.xlsx','Sheet1','L2:P53'); % Matrix with OPEX breakdown - source: Sharma et al. (2013)
    
    % Empty vectors/matrix where to save results
    Overall_avg = zeros(length(WSOs),5); % Number of WSOs across 5 expenditure categories - for saving results
    Processes_total_min = zeros(length(Unit_processes),1); % Vector with all unit processes
    Processes_total_med = zeros(length(Unit_processes),1); % Vector with all unit processes 
    Processes_total_max = zeros(length(Unit_processes),1); % Vector with all unit processes
      
    % Looping through the different plant sizes
    for i=1:length(WSOs)

        if strcmp(WSOs(i),'242c')==0    
    
            sheet = 'TABLE'; 
            Range = 'J5:J47'; % Range corresponds to vector of Total Process Cost
            filename1 = strjoin([num2str(capacity1),'-MGD_WTP_',WSOs(i),'.XLS'],'');
            filename2 = strjoin([num2str(capacity2),'-MGD_WTP_',WSOs(i),'.XLS'],'');

            Plant_min = xlsread(filename1,sheet,Range); % Reading appropriate excel sheet cells 
            Plant_max = xlsread(filename2,sheet,Range); % Reading appropriate excel sheet cells 
            Plant_min(isnan(Plant_min))=0;    
            Plant_max(isnan(Plant_max))=0;
            
            Range_strings = 'B5:B47';
            [~,Plant_min_strings] = xlsread(filename1,sheet,Range_strings); % Reading appropriate excel sheet cells 
            [~,Plant_max_strings] = xlsread(filename2,sheet,Range_strings); % Reading appropriate excel sheet cells 
            
            % Small plant calculations
            index_master = find(ismember(Unit_processes,Plant_min_strings)); % Finding position of unit processes in master list
            index_WTP = find(ismember(Plant_min_strings,Unit_processes));% Finding position of unit processes in WTP list
            Processes_total_min(index_master) = Plant_min(index_WTP); % Extracting the appropriate expenditure shares from master list
            Small_plant = [Processes_total_min,Exp_shares]; % Creating Plant_min matrix 
            Shares_min = Small_plant(:,1)/sum(Small_plant(:,1));
            Avg_min = Shares_min'*Small_plant(:,2:end); % Matrix multiplication to estimate sums of each weighted multiplied column

            % Large plant calculations
            index_master_max = find(ismember(Unit_processes,Plant_max_strings)); % Finding position of unit processes in master list
            index_WTP_max = find(ismember(Plant_max_strings,Unit_processes));% Finding position of unit processes in WTP list
            Processes_total_max(index_master_max) = Plant_max(index_WTP_max); % Extracting the appropriate expenditure shares from master list
            Large_plant = [Processes_total_max,Exp_shares]; % Creating Plant_min matrix 
            Shares_max = Large_plant(:,1)/sum(Large_plant(:,1));
            Avg_max = Shares_max'*Large_plant(:,2:end); % Matrix multiplication to estimate sums of each weighted multiplied column

            Overall_avg(i,:) = (Avg_min+Avg_max)/2; % Overall average for both plants
        
        else
            
            sheet = 'TABLE'; 
            Range = 'J5:J47';
            filename1 = strjoin([num2str(capacity1),'-MGD_WTP_',WSOs(i),'.XLS'],'');
            filename2 = strjoin([num2str(capacity2),'-MGD_WTP_',WSOs(i),'.XLS'],'');
            filename3 = strjoin([num2str(capacity3),'-MGD_WTP_',WSOs(i),'-2.XLS'],'');
            
            Plant_min = xlsread(filename1,sheet,Range); % Reading appropriate excel sheet cells
            Plant_med = xlsread(filename2,sheet,Range);
            Plant_max = xlsread(filename3,sheet,Range); % Reading appropriate excel sheet cells 
            Plant_min(isnan(Plant_min))=0;
            Plant_med(isnan(Plant_med))=0;
            Plant_max(isnan(Plant_max))=0;

            Range_strings = 'B5:B47';
            [~,Plant_min_strings] = xlsread(filename1,sheet,Range_strings); % Reading appropriate excel sheet cells 
            [~,Plant_med_strings] = xlsread(filename2,sheet,Range_strings); % Reading appropriate excel sheet cells 
            [~,Plant_max_strings] = xlsread(filename3,sheet,Range_strings); % Reading appropriate excel sheet cells 
            
            % Small plant calculations
            index_master = find(ismember(Unit_processes,Plant_min_strings)); % Finding position of unit processes in master list
            index_WTP = find(ismember(Plant_min_strings,Unit_processes));% Finding position of unit processes in WTP list
            Processes_total_min(index_master) = Plant_min(index_WTP); % Extracting the appropriate expenditure shares from master list
            Small_plant = [Processes_total_min,Exp_shares]; % Creating Plant_min matrix 
            Shares_min = Small_plant(:,1)/sum(Small_plant(:,1));
            Avg_min = Shares_min'*Small_plant(:,2:end); % Matrix multiplication to estimate sums of each weighted multiplied column
            
            % Medium plant calculations
            index_master_med = find(ismember(Unit_processes,Plant_med_strings)); % Finding position of unit processes in master list
            index_WTP_med = find(ismember(Plant_med_strings,Unit_processes));% Finding position of unit processes in WTP list
            Processes_total_med(index_master_med) = Plant_med(index_WTP_med); % Extracting the appropriate expenditure shares from master list
            Medium_plant = [Processes_total_med,Exp_shares]; % Creating Plant_min matrix 
            Shares_med = Medium_plant(:,1)/sum(Medium_plant(:,1));
            Avg_med = Shares_med'*Medium_plant(:,2:end); % Matrix multiplication to estimate sums of each weighted multiplied column

            % Large plant calculations
            index_master_max = find(ismember(Unit_processes,Plant_max_strings)); % Finding position of unit processes in master list
            index_WTP_max = find(ismember(Plant_max_strings,Unit_processes));% Finding position of unit processes in WTP list
            Processes_total_max(index_master_max) = Plant_max(index_WTP_max); % Extracting the appropriate expenditure shares from master list
            Large_plant = [Processes_total_max,Exp_shares]; % Creating Plant_min matrix 
            Shares_max = Large_plant(:,1)/sum(Large_plant(:,1));
            Avg_max = Shares_max'*Large_plant(:,2:end); % Matrix multiplication to estimate sums of each weighted multiplied column

            Overall_avg(i,:) = (Avg_min+Avg_med+Avg_max)/3; % Overall average for both plants
            
        end
            
    end
    
    scaling_factors = (100./sum(Overall_avg,2)); % Scaling numbers so that total OPEX share equals 100%
    Final_shares = Overall_avg.*repmat(scaling_factors,1,5); % Multiplying each cell by appropriate scaling number
    