%% TBL model necessary inputs
%cd('C:/Users/M-compute/Dropbox/WRRF/' );

%% Option 1 - Carbon-based groundwater recharge

postcode = '23435'; % Virginia postcode
capacity = 1;
flow = 100;
x = xlsread('Costs_testing_HRSD.xlsx','Sheet1','J2:J75');
quantity = xlsread('Costs_testing_HRSD.xlsx','Sheet1','K2:K75');
chemicals = xlsread('Costs_testing_HRSD.xlsx','Sheet1','L2:L31');
defaults = 'defaults';
year = 2016;
purple_pipe = 'No';
dose_units = repmat({'mg/L'},30,1); 
addons = [10 5 20 15 30 35];
%deviation_CAPEX = repmat(33,74,1);
%deviation_OPEX = repmat(20,74,1);

head_transmission = [70 0.6]; % 70 feet
head_purple = [80 0.6];
onsite_energy = [100 0]; % NO Renewable energy
costs = [0 30 5 0]; % Standard costs
solids = [0 0 0 0 ]; %  Solids disposal costs (truckloads)
onsite_fuel = [0;0;0;0;0]; % $ Additional onsite costs
purchased_water = 0;

pumping_transmission = zeros(5,2);
pumping_transmission(1,:)=[capacity,0];
piping_transmission = zeros(6,3);
material_transmission = {'PVC','Ductile Iron','PVC','Ductile Iron','PVC','Ductile Iron'};
pumping_purple = zeros(5,2);
piping_purple = zeros(6,3);
material_purple = {'PVC','Ductile Iron','PVC','Ductile Iron','PVC','Ductile Iron'};

cost_indices = xlsread('Costs_testing_HRSD.xlsx','Sheet1','A2:A18');
chemical_costs = xlsread('Costs_testing_HRSD.xlsx','Sheet1','B2:B31');
purity = xlsread('Costs_testing_HRSD.xlsx','Sheet1','C2:C31');

f = WRRF_WaterSET_US_Matlab_version_32bit_sensitivity_analysis_EST(postcode,capacity,flow,x,quantity,deviation_CAPEX,deviation_OPEX,chemicals,addons,dose_units,head_transmission,pumping_transmission,material_transmission,piping_transmission,purple_pipe,head_purple,pumping_purple,material_purple,piping_purple,solids,defaults,year,costs,purchased_water,onsite_energy,onsite_fuel,cost_indices,chemical_costs,purity);