function [cost_breakdown,value_added,kWh_electricity,m3_natural_gas,L_diesel] = Calculate_OPEX_updated_deviation(x,quantity,deviation_OPEX,chemicals,dose_units,chemical_costs,purity,flow_rate,OPEX_curves,OPEX_indices)
%% FUNCTION READING IN COST CURVE EQUATIONS AND ESTIMATING OPEX
% Author: Michalis Hadjikakou, UNSW
% Last updated: 28/02/2017
% Inputs: x (user input vector - refers to size of each unit process - units vary) & 'Cost_curves.csv' spreadsheet containing: a(x^3-coefficient), b(x^2-coefficient), c(ln coefficient), d(x-coeficient), e (x-power),f(y-intercept) 
% Sources: Sharma et al. (2013), McGivney & Kawamura (2008), Plumley et al. (2014)....
% Outputs: costs, value added and fuel requirements for each WSO

%% 1. Reading in necessary files from directory and setting parameters

    %Costs = readtable('Cost_curves_OPEX.xlsx'); % Spreadsheet containing cost curve relationships for different unit processes
    %Cost_curve_indices = readtable('OPEX_cost_indices.xlsx'); % Spreadsheet containing full range of cost curve indices to allow scaling up/down - better than using single ENR CCI Index
    Costs = OPEX_curves; % Spreadsheet containing cost curve relationships for different unit processes
    Cost_curve_indices = OPEX_indices; % Spreadsheet containing full range of cost curve indices to allow scaling up/down - better than using single ENR CCI Index
    Chem_info = readtable('Chemical_costs.xlsx'); % Spreadsheet containing information for every chemical availabe to tool users (allows matching to appropriate sector)
    ENR_CCI_indices = xlsread('ENR_CCI_timeseries.xlsx','ENR_CCI_timeseries','B2:N28'); % Reading in complete ENR CCI index table - currently ends May 2016
    ENR_CCI_years = xlsread('ENR_CCI_timeseries.xlsx','ENR_CCI_timeseries','A2:A28'); % Reading in years vector (1990-2016)
    [~,ENR_CCI_months] = xlsread('ENR_CCI_timeseries.xlsx','ENR_CCI_timeseries','B1:N1'); % Reading in months vector including Average (length=13)
    
%% 2. Finding correct year/month indices and ensuring all units are compatible    
    
    IO_table_year = 2012; % THIS IS THE THE PRICE YEAR AS FAR AS THE MRIO ANALYSIS IS CONCERNED - LCC still needs to be converted to 2016
    Cost_year = Costs.Year; % Vector of year for which cost curves are applicable - allows scaling to 2012 average on the basis of ENR CCI (see 'ENR_CCI_timeseries.xlsx')  
    Cost_month = Costs.Month; % Vector of month for which costs are available - used to look within ENR CCI table to find appropriate cell
    ENR_index_IO = ENR_CCI_indices(ENR_CCI_years==IO_table_year,strcmp(ENR_CCI_months,'Average')); % Selecting the average ENR CCI for the IO_table_year - can modify accordingly
    
    Cost_scaling_factors = ones(length(Cost_year),1); % Empty vector where scaling factors are to be saved
    
%     for i = 1:length(Cost_year)
%         
%         index_year = ENR_CCI_years==Cost_year(i);
%         index_month = strcmp(ENR_CCI_months,Cost_month(i));
%     
%         if strcmp(Costs.Cost_curve_source(i),'McGivney & Kawamura (2008)') % The McGivney & Kawamura (2008) cost curves are for Los Angeles so this requires additional correction
% 
%             Cost_scaling_factors(i) = ENR_index_IO/ENR_CCI_indices(index_year,index_month)*8889; % By converting ENR CCI to 2007 Los Angeles and then 2012 national prices - see McGivney & Kawamura (2008) and http://www.enr.com/economics
%         % Alternatively can use other indices such as BLS PPI or
%         % Handy-Whitman Index - see supplementary Excel files in McGivney &
%         % Kawamura (2008)
%         % https://www.wrallp.com/about-us/handy-whitman-index - can also be used
%         % for sensitivity analysis to consider how varying costs affect final values  
%     
%         else
%             Cost_scaling_factors(i) = ENR_index_IO/ENR_CCI_indices(index_year,index_month); % Other cost curves are national therefore no additional adjustment required
%     
%         end    
%     
%     end
    
    Cost_scaling_factors(strcmp(Costs.Unit,'$M'))= Cost_scaling_factors(strcmp(Costs.Unit,'$M'))*1000000; % Correcting units - some cost curves are in millions of dollars
    
%% 2. OPEX calculations

    %2.1 Estimate total OPEX based on individual cost curve equation for each unit process 
    
    % Adjusting inputs values from CAPEX to OPEX - see
    % 'CAPEX_input_conversion_factor' in 'Cost_curves_OPEX' spreadsheet
    x(isnan(x))=0; % Ensuring that any NaN values are set to zero
    x = x.*Costs.CAPEX_input_conversion_factor;
    %x(25:29) = x(25:29)./x(25:29);
   
    
    for process = 30 % Gravity filter area is replaced by plant flow rate (to address incompatibility between CAPEX & OPEX cost curves)
        
        if x(process)~=0
            x(process)= flow_rate/quantity(30);
        end    
    end    
    %x(strcmp(Costs.Unit_process,'Gravity Filter Structure'))= flow_rate;
    %x(strcmp(Costs.Unit_process,'Filtration Media - Stratified Sand'))= flow_rate;
    %x(strcmp(Costs.Unit_process,'Filtration Media - Dual Media'))= flow_rate;
    %x(strcmp(Costs.Unit_process,'Filtration Media - Tri-Media'))= flow_rate;
    %x(strcmp(Costs.Unit_process,'Filter Backwash Pumping'))= flow_rate;
    
    a = Costs.Cubic_coef; % Cubic coefficient - zero if none
    b = Costs.Quadratic_coef; % Quadratic coefficient - zero if none
    c = Costs.Logarithm; % Loagarithmic coefficient - zero if none
    d = Costs.Coeficient; % Power function - zero if none
    e = Costs.Power; % x-coefficient - 1 if none
    f = Costs.Intercept; % y-intercept - zero if none

    y = zeros(size(Costs,1),1); % Column vector for saving individual unit process cost estimates
    
    for j = 1:length(Cost_year)
    
        %y(i) = a(i)*x(i)^3 + b(i)*x(i)^2 + c(i)*log(x(i))+ d(i)*x(i)^e(i) + f(i); % Generalised formula for any quadratic, power or linear cost curve- can be modified to include polynomials of higher order
        y(j) = nansum([a(j)*x(j)^3,b(j)*x(j)^2,c(j)*log(x(j)),d(j)*x(j)^e(j),f(j)]); % Ensuring that any NaN values emerging from log(0) values do not throw off the result

    end
    
    quantity(isnan(quantity))=0; % removing NaN values
    y(isinf(y))=0; % removing erroneous -inf values - can occur if user sets too high or too low a number outside range of cost curve (also occurs for logarithmic functions where x=0)
    Total_costs = y.*Cost_scaling_factors.*quantity.*(1+deviation_OPEX/100); % Each vector element multiplied by the number of each unit process plus scaling factor (some cost curves are in $M) plus sensitivity analysis facto (if selected)
    Total_costs(isnan(Total_costs))=0; % removing any NaN values
    %2.2 Calculating OPEX beakdown into individual components (Electricity,
    %Natural gas, Diesel, Labour and Maintenanance) - Note that this
    %ideally need to be adjusted by seperate price indices from the ENR and
    %BLS
    %
    
    CC_matrix = zeros(length(Total_costs),5); % number of rows equal to unit processes and then 8 columns, one for each cost breakdown category 
    
    for i = 1:5 % loop across OPEX categories
        
        CC_matrix(:,i) = (Total_costs.* Costs.(15+i))/100.*(Cost_curve_indices.(9+i)./Cost_curve_indices.(4+i));
        
%         CC_matrix(k,1) = Total_costs(k).* Costs.Electricity(k)/100; % Electricity vector percentage and conversion to physical units - need to consider EIA price changes
%         CC_matrix(k,2) = Total_costs(k).* Costs.Natural_gas(k)/100; % Natural gas vector percentage and conversion to physical units - need to consider EIA price changes
%         CC_matrix(k,3) = Total_costs(k).* Costs.Diesel(k)/100; % Diesel vector percentage and conversion to physical units - need to consider EIA price changes
%         CC_matrix(k,4) = Total_costs(k).* Costs.Labour(k)/100; % Labour vector percentage - NEED TO MULTIPLY BY ENR SKILLED LABOUR WAGE INDEX 
%         CC_matrix(k,5) = Total_costs(k).* Costs.Maintenance(k)/100; % Maintenance vector percentage - NEED TO MULTIPLY BY BLS PPI FOR FINISHED GOODS

    end
    
    CC_vector = sum(CC_matrix); % Total capital cost vector where each element corresponds to the total of each CAPEX category
     
    value_added = CC_vector(4);% Labour - to be added to CAPEX value added to create WSO VA DIM

    cost_breakdown = CC_vector;
    cost_breakdown(4) = []; % Removing labour component from cost breakdown as this should only include intermediate expenditure
    
    %2.3 Adding chemical costs to the cost breakdown
    chemicals(isnan(chemicals))=0; % ensuring that any NaNs are not transferred through 
    purity(isnan(purity))=0; % ensuring that any NaNs are not transferred through
    chemicals(strcmp(dose_units,'mg/L'))= (chemicals(strcmp(dose_units,'mg/L'))*flow_rate*8.34)./purity(strcmp(dose_units,'mg/L')); % The user has options of both mg/L and/or lb/day for each chemical
    %Total_chemical_feed = (chemicals*flow_rate*8.34)./purity; % lb/day = Dose(mg/L) x flow(MGD) x (8.34lbs/gal) - see correction applied below!     
    Total_chemicals = chemicals.*chemical_costs*365;% Costs = feed (lbs/day) * 365 (days in year) x (price per lb)
    
    Inorganic_chemicals = Total_chemicals(strcmp(Chem_info.USA_IO_sector,'All other basic inorganic chemical manufacturing'));
    Chlorine = Total_chemicals(strcmp(Chem_info.USA_IO_sector,'Alkalies and chlorine manufacturing'));
    Organic = Total_chemicals(strcmp(Chem_info.USA_IO_sector,'Other basic organic chemical manufacturing'));
    Black_carbon = Total_chemicals(strcmp(Chem_info.USA_IO_sector,'Carbon black manufacturing'));
    
    cost_breakdown(5) = sum(Inorganic_chemicals);
    cost_breakdown(6) = sum(Chlorine);
    cost_breakdown(7) = sum(Organic);
    cost_breakdown(8) = sum(Black_carbon);
    
    %2.4 Calculating electricity and fuels - ideally these need to use
    %their own respective indices from the Energy Information
    %Administration
    %(http://www.eia.gov/electricity/monthly/epm_table_grapher.cfm?t=epmt_5_3)
    
    kWh_electricity = sum(CC_matrix(:,1)./Costs.Electricity_price_per_kW); % Expenditure divided by average price to obtain quantity (need to update price)
    m3_natural_gas = sum(CC_matrix(:,2)./Costs.Natural_gas_cost_per_m3); % Expenditure divided by average price to obtain quantity (need to update price)
    L_diesel = sum(CC_matrix(:,3)./Costs.Natural_gas_cost_per_m3); % Expenditure divided by average price to obtain quantity (need to update price)
    
end

