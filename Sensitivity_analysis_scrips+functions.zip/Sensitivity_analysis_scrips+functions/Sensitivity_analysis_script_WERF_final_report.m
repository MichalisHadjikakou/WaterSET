%% Script allows user to Run sensitivity analysis for all WSOs at the unit process level by running all WSOs
% Author: Michalis Hadjikakou (University of New South Wales,
% m.hadjikakou@unsw.edu.au)
% Last updated: 31 August 2017
% 
clear

% Matrix to save results
results = zeros(35,6);

%% 1. Specifying deviations for sensitivity analysis - values chosen on the basis of industry survey (see report) and Sharma et al. (2013) J. Infrastruct. Syst. 2013, 19 (4), 451-464.

deviation_CAPEX = repmat(-33,74,1); % Modify first number with negative or positive percentage to change all CAPEX unit process costs - can also produce custom-made vectors where each unit process is varied by a different amount
deviation_OPEX = repmat(20,74,1); % Modify first number with negative or positive percentage to change all OPEX unit process costs - can also produce custom-made vectors where each unit process is varied by a different amount

%% 2. Calling scripts - each of these scripts reads in all inputs from each partner utility 

% OCWD
OCWD_inputs
OCWD_inputs_2
OCWD_inputs_3

% HRSD
HRSD_inputs
HRSD_inputs2
HRSD_inputs3

% Saving results as array
results(:,1)=a;
results(:,2)=b;
results(:,3)=c;
results(:,4)=d;
results(:,5)=e;
results(:,6)=f;

% Rearranging results matrix to correspond to all other results 

Capacity = [30 30 50 1 1 1];

Electricity_per_unit = results(11,:)./(Capacity*365*1000);
Total_CAPEX = sum(results(13:26,:));
Unit_CAPEX = Total_CAPEX./(Capacity*365*1000);
Total_OPEX = sum(results(27:35,:));
Unit_OPEX = Total_OPEX./(Capacity*365*1000);

modified_results = [results(1:11,:);Electricity_per_unit;results(13:26,:);Total_CAPEX;Unit_CAPEX;results(27:35,:);Total_OPEX;Unit_OPEX];

%% 3. Saving output file 

%csvwrite('sensitivity_results_ALL_negativeCAPEX+positiveOPEX.csv',results); % Modify according to scenario/run
csvwrite('Sensitivity/sensitivity_results_negative_CAPEX_positive_OPEX_MOD.csv',modified_results); % Modify according to scenario/run - in this case CAPEX deviation is negative and OPEX deviation is positive