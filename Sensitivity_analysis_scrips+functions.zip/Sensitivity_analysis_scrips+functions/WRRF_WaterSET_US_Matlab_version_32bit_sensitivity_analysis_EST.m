function [results] = WRRF_WaterSET_US_Matlab_version_32bit_sensitivity_analysis_EST(postcode,capacity,flow,x,quantity,deviation_CAPEX,deviation_OPEX,chemicals,addons,dose_units,head_transmission,pumping_transmission,material_transmission,piping_transmission,purple_pipe,head_purple,pumping_purple,material_purple,piping_purple,solids,defaults,year,costs,purchased_water,onsite_energy,onsite_fuel,cost_indices,chemical_costs,purity)
%% WRRF US FUNCTION FOR ESTIMATING QUANTITATIVE TBL IMPACTS BASED ON EE-MRIO MODELLING (master)
%  *Author:* Michalis Hadjikakou, UNSW, Australia
%  *Last updated:* 22/06/2017
%  *Function inputs:* 
% 
% * US postcode: used with eGrid information to perform electricity
% grid-related GHG emissions calculations (see 'eGrid_estimation.m'
% sub-function)
% * Capacity: capacity of proposed project or expansion (in MGD)
% * flow: flow rate as % capacity
% * New_or_existing: Text string specifying whether WSO is from scratch or
% will be added to existing plant - only considers new plants at the moment
% * quantity: user input referring to the selected size of each unit
% process
% * number: user input referring to the number of each selected unit
% process required 
% * purple pipe system: 'Yes' or 'no' depending on WSO - where 'Yes' option
% is selected, head_purple become and active input
% * head (transmission & purple pipe): total head (vertical lift) and losses (major+minor) 
% * solids: number of truckloads and distance to dump site
% * defaults: option to use default or user-specified costs
% * costs: entered when the user goes for the user-specified option
% * onsite_energy: allows users who have onsite renewable electricity
% production to offset their GHG emissions by specifying the percentage of
% energy from the grid in relation to onsite renewables
% * onsite_fuel: any additional onsite fuel burning which may contribute to
% GHG emissions from a certain WSO
% * cost_indices: a vector containing all the latest user-specified price
% indices to ensure that all cost estimates are updated to the present day
% (see Sharma et al. 2013 - J. Infrastruct. Syst., 2013, 19(4): 451-464)
%
% *Function outputs:* a 35-element vector with an estimate of all 10
% Matlab-generated criteria (that is to be added to the criteria mix and
% MCDA algorithm in Excel), in addition to energy estimates, CAPEX
% breakdown and OPEX breakdown.
    
% Initiating variables - placed here for easy updating if necessary
  ENR_CCI_current = cost_indices(1); % User-input - currently April 2016 - this is dynamic 
  ENR_CCI_IO = 9308; % 2012 Average corresponds to MRIO table base year - this is static
  ENR_CCI_series = readtable('ENR_CCI_timeseries.xlsx'); % Historical ENR CCI values - allows extraction of yearly averages (could also use monthly average for more accuracy if desired)
  All_ind_base = readtable('2012_costs.xlsx'); % All indices for base year 
  CAPEX_curves = readtable('Cost_curves_CAPEX_updated.xlsx');
  CAPEX_indices = readtable('CAPEX_cost_indices_updated.xlsx');
  OPEX_curves = readtable('Cost_curves_OPEX_updated.xlsx');
  OPEX_indices = readtable('OPEX_cost_indices_updated.xlsx');
    
%%  1. Reading in necessary files required for function to run (pre-processed using WWRF_TBL.m script) and saved as matlab files to reduce loading time

    %1.1    Pre-processed MRIO variables (T,Q,VA,Y) and LCIA Extensions required
    % for EE-MRIO analysis 
    load('CEDA_Eora_USA_conc.mat') % CEDA-Eora concordance allowing the transfer of LCIA extensions to the Eora MRIO
    load('Dis_T.mat') % Disaggregated AUS-US-CHN-RoW matrix with empty columns/rows for new WSO
    load('Dis_y_US.mat') % Disaggregated final demand vector for US households
    load('Dis_y_AUS.mat')% Disaggregated final demand vector for AUS households
    load('Dis_VA_ALL.mat') % Disaggregated valued added matrix with all 24 sectors (4 for each country/RoW region)
    load('V_labels.mat') %  % Value added labels
    load('New_T_label.mat') % Labels with empty WSO sectors in US USE and Supply matrices - this are to be filled in with values depending on user-specified inputs
    load('CEDA_ext.mat') % Loading all CEDA extensions - TRACI 2.0 direct 2002 USD allocation (Q)
    load('CEDA_indicators.mat') % Loading string vector of CEDA indicator names - each name corresponds to a row in the 'CEDA_ext.mat' matrix
    load('PP_to_BP_Eora_US.mat') % PP to BP factors for Eora US 
    load('PP_to_BP_ISAPC.mat') % PP to BP factors for Eora AUS
    load('Eora_extensions_US.mat') % A comprehensive list of indicators which match the customised MRIO table - offers possibilities in addition to current TBL indicators chosen
    load('Eora_extensions_AUS.mat') % A comprehensive list of indicators which match the customised MRIO table - offers possibilities in addition to current TBL indicators chosen
    load('Eora_extensions_labels.mat') % Short labels for all extensions - could potentially add to this
    
    % 1.2   Running OPEX AND CAPEX cost curve functions - sources: Kawamura & McGivney (2008), Plumlee et al. (2014), Sharma et al. (2013).  
    % This operation uses two custom-made functions 'Calculate_CAPEX.m' and
    % 'Calculate_OPEX.m' which calculate the total CAPEX and OPEX cost
    % breakdowns on the basis of default cost curves for the 69 unit
    % processes available in the tool in 2012 prices (matches the Eora MRIO
    % table)
    flow_rate = flow/100*capacity; % Percentage flow rate at which the plant operates at - allows sensitivity analysis
    [cost_breakdown_CAPEX,value_added_CAPEX,wages_CAPEX] = Calculate_CAPEX_updated_deviation(x,quantity,deviation_CAPEX,CAPEX_curves,CAPEX_indices,addons);
    [cost_breakdown_OPEX,value_added_OPEX,kWh_electricity,scf_natural_gas,gal_diesel] = Calculate_OPEX_updated_deviation(x,quantity,deviation_OPEX,chemicals,dose_units,chemical_costs,purity,flow_rate,OPEX_curves,OPEX_indices);
    
    % 1.3   Calculating annual 2012 MRIO unit costs - PLEASE NOTE THAT THIS DOES NOT
    % CORRESPOND TO FINAL CURRENT LCC VALUE - this is essentially the
    % annualised 'total impact expenditure' which is fed into the
    % 'locate_sectors.m' function - conversion to unit cost occurs later by
    % adding all annualised costs (including electricity and conveyance)
    % and dividing by annual yield
    Annual_CAPEX = cost_breakdown_CAPEX/costs(2); %/(flow_rate*365); % Dividing by the estimated plant service life and annual yield
    Annual_OPEX = cost_breakdown_OPEX; %/(flow_rate*365);  % Dividing by the estimated plant service life and annual yield
    
    VA_annual_CAPEX = value_added_CAPEX/costs(2); %/(flow_rate*365);
    VA_annual_OPEX = value_added_OPEX; %/(flow_rate*365); 
    VA_annual_total = VA_annual_CAPEX+VA_annual_OPEX; % Total annual WSO value added - will be used as national WSO value added extension
    Wages_annual_total = wages_CAPEX/costs(2) + VA_annual_OPEX; % Total annual wages - to be used as national WSO wage extension
    
%%  2. Conveyance, electricity mix and residuals disposal calculations - see 'conveyance.m' and 'eGrid_estimation.m' functions for detailed description of equations and calculations 
    
    % 2.1   Calculating annual conveyance-related electricity and other
    % inputs - from Supply to Water Treatment Facility
    [Pump_electricity_per_year,Conveyance_OPEX_breakdown,Conveyance_CAPEX_breakdown,Pipe_PVC,Pipe_Iron] = conveyance_updated(head_transmission,costs,pumping_transmission,material_transmission,piping_transmission); % Uses updated function where head is aggregated into total
    
    VA_annual_total = VA_annual_total + Conveyance_OPEX_breakdown(4) + Conveyance_CAPEX_breakdown(5); % Adding pumping related estimates
    Wages_annual_total = Wages_annual_total + Conveyance_OPEX_breakdown(4) + Conveyance_CAPEX_breakdown(5); % Adding pumping related 
    
    Annual_OPEX(1:4) = Annual_OPEX(1:4)+ Conveyance_OPEX_breakdown([1,2,3,5]); % Adding conveyance OPEX to total (excluding labour)
    Annual_CAPEX(1:7) = Annual_CAPEX(1:7)+ Conveyance_CAPEX_breakdown([1:6,8]); % Adding conveyance CAPEX to total (excluding labour)
    Annual_CAPEX(12:13) = [Pipe_PVC,Pipe_Iron]; % Adding impact to last two CAPEX positions - see 'CAPEX_sector_concordances_AUS_US.csv'
    
    % 'Pump_electricity_per_year' is the annual amount in kWh required to
    % operate the pump
    % 'Conveyance_OPEX_breakdown' is the breakdown of OPEX expenditure to
    % be added to the rest of the OPEX expenditure (in 2012 USD)
    % 'Conveyance_CAPEX_breakdown' is the breakdown of the annualised CAPEX
    % expenditure to be added to the rest of the CAPEX expenditure (in 2012
    % USD)
    
    % 2.1   Calculating annual conveyance-related electricity and other
    % inputs - Purple Pipe from Facility to Distribution 
    
    if strcmp(purple_pipe,'Yes')==1 % this is an optional component as the system may not have purple pipes, hence the need for an 'if' condition 
        
    [Pump_electricity_per_year_purple,Conveyance_OPEX_breakdown_purple,Conveyance_CAPEX_breakdown_purple,Pipe_PVC_purple,Pipe_Iron_purple] = conveyance_updated(head_purple,costs,pumping_purple,material_purple,piping_purple); % Uses updated function where head is aggregated into total
    
    VA_annual_total = VA_annual_total + Conveyance_OPEX_breakdown_purple(4) + Conveyance_CAPEX_breakdown_purple(5); % Adding pumping related labour estimates for purple pipe
    Wages_annual_total = Wages_annual_total + Conveyance_OPEX_breakdown_purple(4) + Conveyance_CAPEX_breakdown_purple(5); % Adding pumping related labour estimates for purple pipe
    
    Annual_OPEX(1:4) = Annual_OPEX(1:4)+ Conveyance_OPEX_breakdown_purple([1,2,3,5]); % Adding conveyance OPEX to total (excluding labour) - purple pipe component added to existing conveyance
    Annual_CAPEX(1:7) = Annual_CAPEX(1:7)+ Conveyance_CAPEX_breakdown_purple([1:6,8]); % Adding conveyance CAPEX to total (excluding labour)- purple pipe component added to existing conveyance
    Annual_CAPEX(12:13) = [Pipe_PVC+Pipe_PVC_purple,Pipe_Iron+Pipe_Iron_purple]; % Adding impact to last two CAPEX positions - see 'CAPEX_sector_concordances_AUS_US.csv'
    
    Pump_electricity_per_year = Pump_electricity_per_year + Pump_electricity_per_year_purple; % If purple pipe is present then it needs to be added to total electricity demand 
    
    end
    
    % 2.3   Electricity mix calculcations - takes into account conveyance
    % (see 2.1 above) plus all other plant operations (from 1.2 above) - (see 'eGRID.m'function for further details)
    
    All_annual_electricity = (kWh_electricity + Pump_electricity_per_year)/1000; % Summing up all electricity and converting to MWh
    % Electricity estimation based on postcode and onsite energy percentage
    GHG_grid = eGrid_estimation(postcode)*onsite_energy(1)/100*All_annual_electricity*1000; % Calls eGrid_estimation function and calculates annual kg CO2-e from electricity
    GHG_solar = 0.043*onsite_energy(2)/100*All_annual_electricity*1000; % Figure is solar PV factor from NREL LCI in CO2e/kWh (source: http://www.nrel.gov/lci/)
    
    GHG_electricity = GHG_grid + GHG_solar; % Total scope 2 and 3 emissions from electricity supply - NOTE that this is an annual value!
    
    % 2.4   Residuals disposal - costs and CO2 emissions associated with
    % truck fuel consumption
    Trips_per_day = solids(2)/solids(1); % This is simply the truck weight capacity divided by the daily wet residual mass
    Trips_per_day(isnan(Trips_per_day))=0; % Avoid NaN if everything is zero
    Gallons_per_trip = solids(3)/6.4; % This is the distance divided by average heavy-duty track fuel consumption (2010)- source: EIA -see URL reference below
    
    % Solids energy calculations from disposal 
    Solids_disposal_GHG = 10.16*Gallons_per_trip*Trips_per_day*365; % CO2 factor per gallon * gallons of fuel per trip * trips to disposal site per day * days in the year (source: EIA - see URLs below)
    Solids_disposal_cost_2012 = 3.97*Gallons_per_trip*Trips_per_day*365; % This currently only factors in fuel costs but there is also labour and maintenance/cleaning of vehicles involved
    Solids_disposal_cost_current = cost_indices(14)*Gallons_per_trip*Trips_per_day*365; % Same calculation but for current - depends on current price of diesel - Given by user
    
    % Source (GHG of diesel): http://www.eia.gov/tools/faqs/faq.cfm?id=307&t=11
    % Source (Truck fuel consumption): http://www.eia.gov/totalenergy/data/annual/showtext.cfm?t=ptb0208
    % Source (price of diesel per gallon): http://www.eia.gov/dnav/pet/pet_pri_gnd_dcus_nus_m.htm
    % Source (CO2_of_fuels) : https://www.eia.gov/environment/emissions/co2_vol_mass.cfm
    
    Fixed_disposal_cost_current = solids(4); % Adding any fixed disposal costs to the transport component
    
    % 2.5   Purchased water option - this could be made more detailed in
    % the future to allow offsets or additions of environmental impact
    
    Purchased_water = purchased_water;

%%  3. Direct onsite fuel use considerations - costs and GHG calculation
    
    % 3.1   Reading in CO-2e factors (kg CO2-e per gallon) for different
    % fuels - source:
    % https://www.eia.gov/environment/emissions/co2_vol_mass.cfm and
    % calculating CO2 emissions for onsite fuel use
    onsite_fuel = onsite_fuel'; % tranposing to ensure compatability with Excel input column vector
    CO2_gasoline = 8.89*onsite_fuel(1); % in gallons
    onsite_fuel(2) = onsite_fuel(2)+ gal_diesel; % adding any diesel used in unit processes
    CO2_diesel = 10.16*onsite_fuel(2);% in gallons
    CO2_heating_oil = 11.79*onsite_fuel(3);% in gallons
    onsite_fuel(4) = onsite_fuel(4) + scf_natural_gas; % adding any natural gas from unit proceses 
    CO2_natural_gas = 53.12*onsite_fuel(4); % in thousand cubic feet
    CO2_kerosene = 9.75*onsite_fuel(5);% in gallons
    
    Total_onsite_CO2 = sum([CO2_gasoline,CO2_diesel,CO2_heating_oil,CO2_natural_gas,CO2_kerosene]); % Adding up all CO2 from onsite fuels
    
    % 3.2   Costs associated with onsite fuel use - sources:
    % http://www.eia.gov/petroleum/gasdiesel/ 
    % http://www.eia.gov/dnav/pet/pet_pri_wfr_a_EPD2F_prs_dpgal_w.htm
    % http://www.eia.gov/dnav/ng/ng_pri_sum_dcu_nus_m.htm
    % www.eia.gov/dnav/pet/pet_pri_spt_s1_w.htm
    
    Fuel_costs_2012 = [3.52,3.97,3.97,8.10,3.056]; % Vector of costs for all fuels for 2012
    Fuel_costs_current = [cost_indices(15),cost_indices(14),cost_indices(16),cost_indices(13),cost_indices(17)]; % Vector of costs for all fuels for 2016
    
    Costs_2012 = onsite_fuel.*Fuel_costs_2012; % Total costs 2012 disaggregated per fuel as these need to be assigned to different IO sectors 
    Costs_current = sum(onsite_fuel.*Fuel_costs_current); % Sum of total onsite fuel costs 2016 using September 2016 prices - this could be changed if the user wants to enter prices
    
    % 3.3   Preparing all cost vectors for EEIO - only 2012 costs used for
    % EEIO analysis since the model uses 2012 MRIO table
    Petrol_and_diesel = sum(Costs_2012(1:3)); % To be assigned to 'petrol and diesel' OPEX sector
    Kerosene = Costs_2012(5); % To be assigned to 'kerosene' OPEX sector
    Gas = Costs_2012(4); % To be assigned to 'natural gas' OPEX sector
    
    OPEX_all = Annual_OPEX;
    
    OPEX_all(2) = Annual_OPEX(2)+Gas; % Adding onsite fuel costs
    OPEX_all(3) = Annual_OPEX(3)+Petrol_and_diesel+Solids_disposal_cost_2012; % Adding onsite fuel costs
    OPEX_all(9) = Kerosene; % Adding onsite fuel costs
    
    OPEX_CO2 = Annual_OPEX; % This will exclude CO2 from fuels in order to avoid double-counting
    OPEX_CO2(1:3) = 0; % Setting fossil fuels to zeros
    OPEX_CO2(9) = 0; % Setting fossil fuels to zeros
    
%%  4. Setting up MRIO and creating new WSO sector columns in order to allow insertion of new WSO sector

    % 4.1   Finding location of US water sector in Supply and Use matrices
    US_water = find(strcmp(strtrim(table2cell(New_T_label(:,4))),'Water, sewage and other systems'));% Locating original water industry and commodity sector position
    US_water_ind = US_water(1); % US water sector industry position
    US_water_com = US_water(2); % US water sector commodity position
    US_water_ind_inputs = Dis_T(:,US_water_ind); % US water sector current industry recipe
    
    % 4.2   Calculating total output vector and total output/average price of
    % water sector in the US
    Total_output = sum(Dis_T)+sum(Dis_VA_ALL); % Calculating total output vector for all industries and all countries
    Output_US_water_sector = Total_output(US_water_ind);% Determining total output of US water supply sector for 2012
    US_2010_Total_Water_supplied = 15330000; % from('Water_utility_stats/US Water Use 2010 fm USGS.xlsx','Sheet1','D36'); % Total public water supply in million gallons per year
    US_2012_Avg_water_price = (Output_US_water_sector/1000)/US_2010_Total_Water_supplied; % Average price in 2012 USD for each gallon supplied - works out at about $0.75 per 1000 gallons (in basic prices)
    
    %%%%%% NEEED TO CONSIDER WHETHER PRICE SHOULD BE CALCULATED ON THE
    %%%%%% BASIS OF ONLY THE INTERMEDIATE INPUTS OR THE TOTAL
    %%%%%% OUTPUT!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    %Avg_new_water_price = (Output_US_water_sector/1000)
    
    %US_water_com = US_water_com+1; % Need to add 1 because disaggregation will move this by one position
    
    % 4.3  Creating empty columns and rows for WSO option
    % Adding two empty columns to use and supply matrix respectively 
    T_new1 = [Dis_T(:,1:US_water_ind) zeros(length(Dis_T),1) Dis_T(:,US_water_ind+1:US_water_com) zeros(length(Dis_T),1) Dis_T(:,US_water_com+1:end)];
    % Adding two empty rows to use and supply matrix respectively 
    T_new2 = [T_new1(1:US_water_ind,:); zeros(1,length(T_new1)); T_new1(US_water_ind+1:US_water_com,:); zeros(1,length(T_new1)); T_new1(US_water_com+1:end,:)];
    % Creating new labels to include the new WSO sector
    New_T_label = table2cell(New_T_label); % Converting table to cell to allow easier manipulation
    New_sector_labels = [New_T_label(1:US_water_ind,4); 'WSO'; New_T_label(US_water_ind+1:US_water_com,4); 'WSO'; New_T_label(US_water_com+1:end,4)];
    
    WSO_ind_pos = US_water_ind+1; % Empty WSO industry sector index
    WSO_com_pos = US_water_com+2; % Empty WSO commodity sector index - need to add two becomes everything has shifted by one row/column since two new rows/columns have been added (one for USE table and another for SUPPLY table) 
    
    % 4.4 Creating CAPEX expenditure categories sector concordances
    All_CAPEX = readtable('CAPEX_sector_concordances_AUS_US.csv','ReadRowNames',true); % Reading table with IO sectors receiving CAPEX spending
    CAPEX_conc = table2cell(All_CAPEX); % Converting table to cell to allow easy manipulation
    
    CAPEX_inputs = locate_sectors_US(CAPEX_conc,New_sector_labels,Annual_CAPEX,T_new2); % Using custom-made locate_sectors.m function which distributes all expenditure to the right sectors
    % Please note that this converts $ to $k which is consistent with Eora
    % MRIO (in 1000s of USD)
    
    % 4.5 Creating OPEX expenditure categories sector concordances
    All_OPEX = readtable('OPEX_sector_concordances_AUS_US.xlsx','ReadRowNames',true); % Reading table with IO sectors receiving CAPEX spending
    OPEX_conc = table2cell(All_OPEX); % Converting table to cell to allow easy manipulation
    
    OPEX_inputs = locate_sectors_US(OPEX_conc,New_sector_labels,OPEX_all,T_new2); % Using custom-made locate_sectors.m function which distributes allo expenditure to the right sectors
    OPEX_CO2_inputs = locate_sectors_US(OPEX_conc,New_sector_labels,OPEX_CO2,T_new2); % Repeating for CO-2 specific inputs (with electricity and onsite fuels removed to avoid double-counting)
    
    All_costs = OPEX_inputs+CAPEX_inputs; % Intermediate inputs column to be inserted into matrix to calculate environmental and other extensions other than CO2
    All_CO2_costs = OPEX_CO2_inputs+CAPEX_inputs; % Intermediate inputs column to be inserted into matrix to calculate CO2
    
    % 4.6 Inserting inputs into T-matrix 
    T_complete = T_new2; 
    T_complete(:,WSO_ind_pos)= All_costs;
    T_complete(WSO_ind_pos,WSO_com_pos)= (sum(Annual_CAPEX) + sum(Annual_OPEX) + VA_annual_total)/1000; % In Supply matrix the WSO industry supplies only one product, WSO water
    
    T_complete_CO2 = T_new2;
    T_complete_CO2(:,WSO_ind_pos)= All_CO2_costs;
    T_complete_CO2(WSO_ind_pos,WSO_com_pos)= (sum(Annual_CAPEX) + sum(OPEX_CO2) + VA_annual_total)/1000; % In Supply matrix the WSO industry supplies only one product, WSO water
    
%%  5. Performing EEIO analysis - based on concept of insertion of new sector in the economy - see Malik et al. (2015) and 'Intermediate_vs_final_demand_analysis.xls'(Wiedmann, 2015)

    %  5.1 Disaggregating the extensions to include the new WSO sector
    
    % Eora DIMs disaggregation to include new sector 
    Q = All_indicators_US([1,2,3,5],:); % Change according to whther tool is for Australia or US
    Total_output = Total_output .* (Total_output>1);  % set small and negative values to zero;
    % this is necessary to prevent negative and huge DIMs (check with and without).   
    DIMs = Q./repmat(Total_output,size(Q,1),1); % Calculating direct impact multipliers excluding value added which needs to be kept in dollar value 
    DIMs_new =[DIMs(:,1:US_water_ind) DIMs(:,US_water_ind) DIMs(:,US_water_ind+1:US_water_com) DIMs(:,US_water_com) DIMs(:,US_water_com+1:end)]; % Assuming that DIM of WSO is same as DIM of water industry
    Employment_VA = [sum(Dis_VA_ALL([7:12],:));Dis_VA_ALL(7,:);sum(Dis_VA_ALL);sum(Dis_VA_ALL([1,7,13,19],:))]./repmat(Total_output,4,1); % Selecting the value added and wages - in this case no DIM calculation is required because Q = DIM
    Employment_VA_new = [Employment_VA(:,1:US_water_ind) Employment_VA(:,US_water_ind) Employment_VA(:,US_water_ind+1:US_water_com) Employment_VA(:,US_water_com) Employment_VA(:,US_water_com+1:end)];
    
    % Correcting VA and wages extensions
    Employment_VA_new([1,3],WSO_ind_pos) = VA_annual_total/1000/T_complete(WSO_ind_pos,WSO_com_pos); % Setting VA values to WSO VA values - Please note that these values are now in $k to ensure compatibility with other sectors
    Employment_VA_new([2,4],WSO_ind_pos) = Wages_annual_total/1000/T_complete(WSO_ind_pos,WSO_com_pos); % Setting wage values to WSO wage values - Please note that these values are now in $k to ensure compatibility with other sectors
    
    DIMs_selected = [DIMs_new;Employment_VA_new]; % Concatenating chosen indicators into one matrix 
    
    % Harmonising the CEDA extensions with the Eora MRIO - US ONLY
    % (note that the original CEDA DIMs assume 2002 economic allocation)
    LCIA_indicators = strrep(strtrim(indicators),'''',''); % Removing all leading or trailing spaces and apostrophes in strings
    Ecotoxicity_US = CEDA_Eora_conc*(CEDA_ext(strcmp(LCIA_indicators,'ecotox'),:))'; % Selecting ecotoxicity vector and multiplying by concordance to convert into Eora US classification
    Eutrophication_US = CEDA_Eora_conc*(CEDA_ext(strcmp(LCIA_indicators,'Eutrophication'),:))';% Selecting ecotoxicity vector and multiplying by concordance to convert into Eora US classification
    Human_toxicity_can = CEDA_Eora_conc*(CEDA_ext(strcmp(LCIA_indicators,'HH_can'),:))';% Selecting human toxicity (cancerous) and multiplying by concordance to convert into Eora US classification
    Human_toxicity_noncan = CEDA_Eora_conc*(CEDA_ext(strcmp(LCIA_indicators,'HH_noncan'),:))';% Selecting human toxicity (non-cancerous) and multiplying by concordance to convert into Eora US classification
    Human_toxicity_total = Human_toxicity_can+Human_toxicity_noncan; % Total human toxicity
    Land_use = CEDA_Eora_conc*(CEDA_ext(strcmp(LCIA_indicators,'Land Use'),:))'; % US-specific land use
    Water_use = CEDA_Eora_conc*(CEDA_ext(strcmp(LCIA_indicators,'Water Consumption'),:))'; % US-specific land use
    All_LCIA = [Eutrophication_US';Ecotoxicity_US';Human_toxicity_total';Land_use';Water_use']; % Concatenating vectors into one matrix
    IO_Inflation_deflation_factors = readtable('Industry_by_industry_inflation_factors.xlsx'); % Source: Chain-Type Price Indexes for Gross Output by Industry (http://bea.gov/iTable/iTable.cfm?ReqID=51&step=1#reqid=51&step=2&isuri=1)
    % U.S. Bureau of Economic Analysis, �Table name,� [the URL] (accessed [date]).
    Inflation_factor = (CEDA_Eora_conc*IO_Inflation_deflation_factors.x2002)./(CEDA_Eora_conc*IO_Inflation_deflation_factors.x2011); % Note that 2011 is the latest year in the timeseries that is the closest to 2012
    LCA_DIMs = All_LCIA.*repmat(Inflation_factor',size(All_LCIA,1),1); % LCA DIMs now adjusted to 2011 prices 
    
    % Ensuring unit compatability!!! CEDA DIMs are per dollar so this
    % needs to be factored in later - no need to convert
    
    % Creating US-specific CEDA-Eora extensions (specialised Q block) 
    US_sector_index = find(strcmp(New_T_label(:,2),'USA')); % Determining position of US industry sectors
    US_industry_length = find(strcmp(New_T_label(US_sector_index,3),'Industries')); % Determining position of last industry sector
    US_industry_index = US_sector_index(1):(US_sector_index(1)+US_industry_length(end)-1); % Continuous first and last vector in order to position CEDA extensions in the MRIO
    LCA_ext = [zeros(size(LCA_DIMs,1),US_sector_index(1)-1), LCA_DIMs, zeros(size(LCA_DIMs,1),length(US_industry_index(end)+1:length(Dis_T)))]; % Specialised DIM block for US - everything else set to zero
    LCA_ext_new = [LCA_ext(:,1:US_water_ind) LCA_ext(:,US_water_ind) LCA_ext(:,US_water_ind+1:US_water_com) LCA_ext(:,US_water_com) LCA_ext(:,US_water_com+1:end)]; % Disaggregating into new classification - assuming that DIM for WSO is the same as that of the original US water sector
    
    %   5.2 Running EEIO analysis using calculate_multipliers function
    All_DIMs = [DIMs_selected;LCA_ext_new]; % Concatenating all DIMs
    All_indicator_labels = categorical({'CF','EF','WF','Employment','VA US','Wages US','VA global','Wages global','Eutrophication','Ecotoxicity','Human toxicity','Land use(local)','Water use(local)'});
    %%%%%%%%% TOTAL OUTPUT NEEDS TO INCLUDE ALL ELECTRICITY AND HEAD/ENERGY
    %%%%%%%%% PLUS SOLIDS DISPOSAL !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    Total_output_new =[Total_output(:,1:US_water_ind) 0 Total_output(:,US_water_ind+1:US_water_com) 0 Total_output(:,US_water_com+1:end)];
    Total_output_new([WSO_ind_pos,WSO_com_pos])= (sum(Annual_CAPEX) + sum(Annual_OPEX) + VA_annual_total)/1000; % Adding up all input costs and converting to $k
    Total_output_new_CO2 = Total_output_new; % Seperate total input vector for CO2
    Total_output_new_CO2([WSO_ind_pos,WSO_com_pos])= (sum(Annual_CAPEX) + sum(OPEX_CO2) + VA_annual_total)/1000; % Adding up all input costs and converting to $k
    
    % Performing EEIO seperately for CO2 and other extensions to avoid
    % double-counting 
    All_TIMs = Calculate_criteria_TIMs(Total_output_new,All_DIMs(2:end,:),T_complete); % Calculating total impact multipliers using 'Calculate_criteria_TIMs.m' function
    CO2_TIMs = Calculate_criteria_TIMs(Total_output_new_CO2,All_DIMs(1,:),T_complete_CO2); % Seperating out CO2 to avoid double-counting (T and total output should be different)
    
    % Selecting WSO TIMs and converting to yield equivalent tp ensure compatibility with unit costs 
    Annual_impacts = [CO2_TIMs;All_TIMs]; 
    Annual_impacts(1:4,:) = Annual_impacts(1:4,:)/1000;% Converting TIMs to per dollar values instead of per $k - this is not necessarily for the CEDA TIMs
    WSO_TIMs = Annual_impacts(:,WSO_com_pos); % TIMs for WSO per 1 USD
    
    % Necessary unit conversions to ensure that all indicators are
    % presented in the right units
    Conversion_vector = [1000000 1 1000 1000 1 1 1 1 1 1 1 1 1]; % Converting Gg to kg (CO2), m3 to L (water)
    WSO_TIMs = WSO_TIMs.*Conversion_vector'; % More intuitive units (still in per dollar terms)
    Additional_GHG = (GHG_electricity+Total_onsite_CO2+Solids_disposal_GHG)/(flow_rate*365)/1000; % kg GHG per 1000 gallons
    
    Avg_WSO_water_price = (Total_output_new(WSO_com_pos)*1000)/(flow_rate*365*1000);% per MGD produced (US) - around $2.7 per 1000 gallons - this is reasonable
        
    WSO_unit_impact = WSO_TIMs*Avg_WSO_water_price; % converts all impacts to impacts per 1000 gallons
    WSO_unit_impact(1) = WSO_unit_impact(1)+ Additional_GHG; % Adding the GHG from electricity and onsite fuels to complete the GHG emissions per 1000 gallons
    
%%  6. Life cycle costing - defaults or model-generated (will depend on user choice and discount rates etc)   
    
    % 6.1   Standard LCC calculations using indexes to update to most
    % current prices
    % Costs required irrespective of whether user wishes to enter them or
    % not - the MRIO model uses them in the calculations 
    
    % Defaults or model-calculated life cycle costs? 
    %inflation_table = csvread('US_inflation_rates.csv'); % Reading in table with US inflation_rates for 1980-2018 - sources: WDI, http://www.usinflationcalculator.com/inflation/current-inflation-rates/, https://knoema.com/kyaewad/us-inflation-forecast-2015-2020-and-up-to-2060-data-and-charts
    %inflation_rate = calculate_inflation(inflation_table,2016); % Please note that this is actually a deflation rate from 2016 to 2012 but this could be an inflation rate if the user actually provides costs
    
    Total_water = flow_rate*365*costs(2)*1000; % Total volume of water produced equal to daily flow rate x 365 x plant service life x 1000 (convert from MGD to 1000s of gallons)
    
    % Index_adjustments for each individual cost breakdown category and
    % adding all current costs to ensure most updated estimate is used in
    % the LCC calculation (below)
    Annual_OPEX_current = sum(Annual_OPEX.*[cost_indices([12:14,10])',1,1,1,1]./[All_ind_base.value_2012([12:14,10])',1,1,1,1])+Solids_disposal_cost_current+Fixed_disposal_cost_current+Purchased_water+Costs_current; % Adding up ALL O&M costs!
    
    cost_breakdown_CAPEX_current = costs(2)*(Annual_CAPEX.*[cost_indices([2:5,7:9,7,2,8,1])',1,1]./[All_ind_base.value_2012([2:5,7:9,7,2,8,1])',1,1]);
    
    if strcmp(purple_pipe,'Yes')==1 % Purple pipe VA needs to be added!

    value_added_CAPEX_current = costs(2)*(VA_annual_CAPEX+Conveyance_CAPEX_breakdown(5)+Conveyance_CAPEX_breakdown_purple(5))*cost_indices(6)/All_ind_base.value_2012(6);
    VA_annual_OPEX_current = (VA_annual_OPEX+Conveyance_OPEX_breakdown(4)+Conveyance_OPEX_breakdown_purple(4))*cost_indices(11)/All_ind_base.value_2012(11); % Adjusting on the basis of labor wage per hour
    
    else
        
    value_added_CAPEX_current = costs(2)*(VA_annual_CAPEX+Conveyance_CAPEX_breakdown(5))*cost_indices(6)/All_ind_base.value_2012(6);
    VA_annual_OPEX_current = (VA_annual_OPEX+Conveyance_OPEX_breakdown(4))*cost_indices(11)/All_ind_base.value_2012(11); % Adjusting on the basis of labor wage per hour
    
    end
    
    % Calculating NPV costs and life cycle cost per unit
    if strcmp(defaults,'defaults')==1
        
        OPEX_timeseries = repelem(Annual_OPEX_current+VA_annual_OPEX_current,costs(2)); % Generating OPEX timeseries for the whole WSO life cycle
        NPV_OPEX = zeros(costs(2),1);
        
        for i = 1:costs(2)
            NPV_OPEX(i) = OPEX_timeseries(i)*((1+costs(3)/100)^-i); % Generating OPEX timeseries in NPV by applying discount rate - see standard NPV calculation (source: NSW Treasury, 2004)
        end  
            
        Total_NPV = sum(cost_breakdown_CAPEX_current)+ value_added_CAPEX_current + sum(NPV_OPEX); % Total costs in net present value terms
        LCC = Total_NPV/Total_water; % LCC per functional unit simply the total cost in NPV divided by total volume of water produced
        Variable_cost = sum(NPV_OPEX)/Total_NPV*100; % Variable cost as a percentage of total costs
        
%         LCC = (sum(Annual_CAPEX)*(costs(3)/100+1) + sum(Annual_OPEX) + VA_annual_total)*1/inflation_rate/(flow_rate*365*1000); % LCC per 1000 gallons
%         Variable_cost = (sum(Annual_OPEX) + VA_annual_total)/(flow_rate*365*1000);
        
    elseif strcmp(defaults,'own_costs_pre2016')==1% This is where the user wishes to 'override' model by entering their 'own costs' instead
        
        %year = str2num(defaults); % Ensures year is a number
        ENR_past = ENR_CCI_series.Average(ENR_CCI_series.Year==year); % Finds the right yearly average ENR CCI
        costs(4)= costs(4)*ENR_CCI_current/ENR_past; % Updates the OPEX estimate based on ENR CCI relationships
        OPEX_timeseries = repelem(costs(4),costs(2)); % Generating OPEX timeseries for the whole WSO life cycle
        NPV_OPEX = zeros(costs(2),1);
        
        for i = 1:costs(2)
            NPV_OPEX(i) = OPEX_timeseries(i)*((1+costs(3)/100)^-i);
        end
        
        Total_NPV = (costs(1)*ENR_CCI_current/ENR_past)+ sum(NPV_OPEX); % Total costs in net present value with index update 
        LCC = Total_NPV/Total_water; % LCC per functional unit simply the total cost in NPV divided by total volume of water produced
        Variable_cost = sum(NPV_OPEX)/Total_NPV*100; % Variable cost as a percentage of total costs
     
    else
        %ENR_past = ENR_CCI_series.Average(ENR_CCI_series.Year==year); % Finds the right yearly average ENR CCI
        %costs(4)= costs(4)*ENR_CCI_current/ENR_past; % Updates the OPEX estimate based on ENR CCI relationships
        OPEX_timeseries = repelem(costs(4),costs(2)); % Generating OPEX timeseries for the whole WSO life cycle
        NPV_OPEX = zeros(costs(2),1);
        
        for i = 1:costs(2)
            NPV_OPEX(i) = OPEX_timeseries(i)*((1+costs(3)/100)^-i);
        end
        
        Total_NPV = costs(1)+ sum(NPV_OPEX); % Total costs in net present value with index update 
        LCC = Total_NPV/Total_water; % LCC per functional unit simply the total cost in NPV divided by total volume of water produced
        Variable_cost = sum(NPV_OPEX)/Total_NPV*100; % Variable cost as a percentage of total costs
        
%         LCC = (costs(1)/costs(2)*(costs(3)/100+1)+costs(4))/(flow_rate*365*1000);  % This needs to be corrected to reflect UNIT COSTS FORMULATION AND DISCOUNTING!!!!
%         Variable_cost = costs(4)/(flow_rate*365*1000); 
    end
     
%     if new_or_existing == 'new'
%         O_M = 0;
%     elseif new_or_existing == 'old'
%         O_M = 10;
%     else
%         O_M = 500;
%     end
    
%%  7. Generating final function outputs   

    M1 = LCC; % Equal to LCC per unit (essentially discounted unit cost)
    %M2 = WSO_unit_impact(5); % US value added ($) per unit 
    %M3 = WSO_unit_impact(7); % Global value added ($) per unit
    M2 = WSO_unit_impact(6); % US wage contribution (income part of value added)
    M3 = Variable_cost; % Variable cost percentage
    M4 = (1-WSO_unit_impact(5)/WSO_unit_impact(7))*100; % Percentage of exported value added
    %M5 = WSO_unit_impact(8); % Global wage contribution (income part of value added)
    M9 = WSO_unit_impact(4)*1000; % Employment (number of persons)
    M5 = WSO_unit_impact(1); % CO2-eq (kg) Solids_disposal_GHG+GHG_onsite+Total_GHG; % Total GHG - to this we need to add the supply chain emissions from all other sources (MRIO)
    M6 = WSO_unit_impact(end); % Total water footprint per unit cost (kg) - CEDA
    M7 = WSO_unit_impact(9); % Eutrophication potential (kg N eq) - CEDA
    M8 = WSO_unit_impact(10); % Ecotoxicity potential (CTUE) - CEDA
    M10 = WSO_unit_impact(11);  % Human toxicity potential (CTUH) - CEDA
    %M12 = WSO_unit_impact(end-1); % Land footprint (acres) - CEDA
    %M13 = WSO_unit_impact(2); % Global ecological footprint(gha) - source (Eora)
    
    CAPEX_ALL = [Annual_CAPEX';VA_annual_CAPEX];
    OPEX_ALL = [Annual_OPEX';VA_annual_OPEX];
    selected_diagnostics =[kWh_electricity; Pump_electricity_per_year;];
    
    results = [M1;M2;M3;M4;M5;M6;M7;M8;M9;M10;selected_diagnostics;CAPEX_ALL;OPEX_ALL];

    
end

